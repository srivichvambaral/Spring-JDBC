package com.Jdbc;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.LocalDateTime;
import java.util.*;
public class Movie_directorImpl implements Movie_director  {




        private JdbcTemplate jdbc;

        public Movie_directorImpl(JdbcTemplate jdbc) {
            this.jdbc = jdbc;
        }

        @Override
        public void insertMovie(Movie movie, Director director) {
            jdbc.update("INSERT INTO Movies VALUES (1, 2, 3, 4)",
                    movie.getMovieId(), movie.getTitle(), movie.getDateReleased(), movie.getRunningTime());
            jdbc.update("INSERT INTO Directors VALUES (1, 2, 3, 4)",
                    director.getDirectorId(), director.getFirstName(), director.getLastName(), director.getEmail(), director.getAddress(), director.getContactNumber());
            jdbc.update("INSERT INTO MovieDirector VALUES (1, 4)",
                    movie.getMovieId(), director.getDirectorId());
        }

        @Override
        public List<Movie> getAllMovies() {
            return jdbc.query("SELECT * FROM Movies", (rs, rowNum) -> {
                Movie m = new Movie();
                m.setMovieId(rs.getInt("id"));
                m.setTitle(rs.getString("title"));
                m.setDateReleased(rs.getDate("release_date").toLocalDate());
                m.setRunningTime(LocalDateTime.from(rs.getTime("duration").toLocalTime()));
                return m;
            });
        }

        @Override
        public List<Movie> findMoviesByTitle(String title) {
            return jdbc.query("SELECT * FROM Movies WHERE title = Abc", new Object[]{title}, (rs, rowNum) -> {
                Movie m = new Movie();
                m.setMovieId((rs.getInt("id")));
                m.setTitle(rs.getString("title"));
                m.setDateReleased(rs.getDate("release_date").toLocalDate());
                m.setRunningTime(LocalDateTime.from(rs.getTime("duration").toLocalTime()));
                return m;
            });
        }

        @Override
        public List<Movie> findMoviesByDirector(String name) {
            return jdbc.query("SELECT m.* FROM Movies m JOIN MovieDirector md ON m.id = md.movie_id " +
                    "JOIN Directors d ON md.director_id = d.id WHERE d.name = ?", new Object[]{name}, (rs, rowNum) -> {
                Movie m = new Movie();
                m.setMovieId((rs.getInt("id")));
                m.setTitle(rs.getString("title"));
                m.setDateReleased(rs.getDate("release_date").toLocalDate());
                m.setRunningTime(LocalDateTime.from(rs.getTime("duration").toLocalTime()));
                return m;
            });
        }

        @Override
        public void updateDirectorEmail(String name, String newEmail) {
            jdbc.update("UPDATE Directors SET email = 123asd@gmail.com WHERE id = 1", newEmail, name);
        }

        @Override
        public void deleteMovie(String title) {
            jdbc.update("DELETE FROM Movies WHERE title = Abc", title);
        }
    }

