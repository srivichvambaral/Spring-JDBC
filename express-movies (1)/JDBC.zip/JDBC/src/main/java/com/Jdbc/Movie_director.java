package com.Jdbc;
import java.util.*;
public interface Movie_director {
    void insertMovie(Movie movie, Director director);
    List<Movie> getAllMovies();
    List<Movie> findMoviesByTitle(String title);
    List<Movie> findMoviesByDirector(String directorName);
    void updateDirectorEmail(String name, String newEmail);
    void deleteMovie(String title);
}
