package com.Jdbc;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.time.LocalDateTime;

import java.time.LocalDate;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("Config.xml");
       // Movie_directorImpl dao = context.getBean("dao",Movie_directorImpl.class);
        Movie movie = context.getBean("movie", Movie.class);
        Director director = context.getBean("director", Director.class);

       /* Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Add Movie & Director");
            System.out.println("2. View All Movies");
            System.out.println("3. Search Movie by Title");
            System.out.println("4. Search Movies by Director Name");
            System.out.println("5. Update Director Email");
            System.out.println("6. Delete Movie by Title");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt(); sc.nextLine();

            switch (ch) {
                case 1 -> {


                    System.out.print("Movie ID: ");
                    movie.setMovieId(sc.nextInt()); sc.nextLine();
                    System.out.print("Title: ");
                    movie.setTitle(sc.nextLine());
                    System.out.print("Release Date (yyyy-mm-dd): ");
                    movie.setDateReleased(LocalDate.parse(sc.nextLine()));
                    System.out.print("Running Time (yyyy-mm-ddTHH:mm): ");
                    movie.setRunningTime(LocalDateTime.parse(sc.nextLine()));

                    System.out.print("Director ID: ");
                    director.setDirectorId(sc.nextInt()); sc.nextLine();
                    System.out.print("First Name: ");
                    director.setFirstName(sc.nextLine());
                    System.out.print("Last Name: ");
                    director.setLastName(sc.nextLine());
                    System.out.print("Email: ");
                    director.setEmail(sc.nextLine());
                    System.out.print("Address: ");
                    director.setAddress(sc.nextLine());
                    System.out.print("Contact Number: ");
                    director.setContactNumber(sc.nextInt()); sc.nextLine();

                    dao.insertMovie(movie, director);
                    System.out.println("Inserted successfully.");
                }

                case 2 -> {
                    List<Movie> movies = dao.getAllMovies();
                    if (movies.isEmpty()) {
                        System.out.println("No records found.");
                    } else {
                        movies.forEach(m -> System.out.println(m.getMovieId() + " | " + m.getTitle() + " | " + m.getDateReleased()));
                    }
                }

                case 3 -> {
                    System.out.print("Enter title to search: ");
                    String title = sc.nextLine();
                    List<Movie> result = dao.findMoviesByTitle(title);
                    if (result.isEmpty()) System.out.println("No match found.");
                    else result.forEach(m -> System.out.println( m.getTitle() + " (" + m.getDateReleased() + ")"));
                }

                case 4 -> {
                    System.out.print("Enter director name to search: ");
                    String name = sc.nextLine();
                    List<Movie> result = dao.findMoviesByDirector(name);
                    if (result.isEmpty()) System.out.println("No movies found.");
                    else result.forEach(m -> System.out.println( m.getTitle()));
                }

                case 5 -> {
                    System.out.print("Enter director name to update: ");
                    String name = sc.nextLine();
                    System.out.print("Enter new email: ");
                    String email = sc.nextLine();
                    dao.updateDirectorEmail(name, email);
                    System.out.println("Email updated.");
                }

                case 6 -> {
                    System.out.print("Enter movie title to delete: ");
                    String title = sc.nextLine();
                    dao.deleteMovie(title);
                    System.out.println("🗑Movie deleted.");
                }

                case 7 -> {
                    System.out.println("Exiting...");
                    sc.close();
                    System.exit(0);
                }

                default -> System.out.println("Invalid choice.");
            }
        }
    }*/
}}
